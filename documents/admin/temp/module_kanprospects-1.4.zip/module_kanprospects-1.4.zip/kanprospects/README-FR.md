# KanProspects

KanProspects est un module Dolibarr qui permet d'implémenter la vue Kanban pour Prospects.

Documentation utilisateur : https://doc.progsi.ma/fr/kanprospects
Démo : https://kanview.progsi.ma  
utilisez l'entrée du menu gauche "Prospects", ou :
allez à "Tiers", puis entrée du menu gauche "Kanban" sous "Liste prospects"


## LICENCE

KanProspects est distribué sous les termes de la licence AGPL v3 ou supérieure (voir fichiers COPYING et COPYRIGHT).


## INSTALLER KanProspects

KanProspects s'installe dans Dolibarr comme tout autre module.
1- Lorsque vous aurez récupéré le .zip du module, dézippez le dans htdocs ou dans htdocs/custom, 
htdocs étant la racine de votre Dolibarr (qui peut avoir un autre nom dans votre installation).
2- Allez dans Accueil > Configuration > Modules/Applications
3- Cherchez l'entrée "Vue Kanban des Prosppects" ou "KanProspects" dans la liste des modules
4- Activez-le
5- Clickez sur le menu haut "Tiers", vous remarquerez qu'une entrée du menu gauche "Kanban" a été ajoutée sous "Liste prospects"
6- Clickez sur cette entrée "Kanban" pour afficher la vue Kanban des prospects






